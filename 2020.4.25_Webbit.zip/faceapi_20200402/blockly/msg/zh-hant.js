MSG.faceapirecognition = "人臉辨識 (face-api)";

MSG.faceapirecognition = "人脸辨识 (face-api)";

MSG.myBlocks = "My Blocks";
MSG.myCategory1 = "Category 1";
MSG.myCategory2 = "Category 2";
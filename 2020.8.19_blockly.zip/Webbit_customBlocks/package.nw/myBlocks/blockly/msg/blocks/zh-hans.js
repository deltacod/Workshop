Blockly.Msg.digitalWrite = "数位写入";
Blockly.Msg.digitalRead = "数位读取";
Blockly.Msg.digitalWrite = "digitalWrite";
Blockly.Msg.digitalRead = "digitalRead";
+(function (window, document) {

  'use strict';

 function digitalWrite(pin, val) {
	var url = "http://192.168.1.100/?digitalwrite="+pin+";"+val;
	console.log(url);
 }

 function digitalRead(pin) {
	var url = "http://192.168.1.100/?digitalread="+pin;
	console.log(url);
	return 1;
 }

  window.digitalWrite = digitalWrite;
  window.digitalRead = digitalRead;

}(window, window.document));
